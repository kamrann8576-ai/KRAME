# KRAMÉ (Monorepo) - Backend + Frontend

This repository is a GitHub-ready monorepo for the KRAMÉ e-commerce store.

## Steps to deploy (quick)
1. Rename this repository to `krame` and push to your GitHub account.
2. Replace placeholders in `backend/.env.example` and `frontend/.env.example`.

## Deploy Backend to Render
1. Create a new Web Service on Render and connect to this repo.
2. Set the build command to `npm install` and start command to `npm start`.
3. Set environment variables listed in `backend/.env.example`.

## Deploy Frontend to Vercel
1. Connect this repo to Vercel (select the frontend folder).
2. Set `REACT_APP_API_URL` to your backend URL in Vercel dashboard.

## GitHub Actions
- CI workflows are included that build the frontend and backend on push.
