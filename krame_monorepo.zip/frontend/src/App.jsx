import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './index.css';
function App() {
  const [products, setProducts] = useState([]);
  const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';
  useEffect(() => {
    axios.get(API + '/api/products')
      .then(res => setProducts(res.data.products || []))
      .catch(err => console.error(err));
  }, []);
  return (
    <div style={{ fontFamily: 'Inter, system-ui, sans-serif', background:'#000', color:'#fff', minHeight:'100vh' }}>
      <header style={{ padding:'20px', display:'flex', alignItems:'center', gap:20 }}>
        <div style={{ background:'#d4af37', color:'#000', padding:12, borderRadius:8, fontWeight:700 }}>K</div>
        <h1 style={{ margin:0 }}>KRAMÉ</h1>
      </header>
      <main style={{ padding:20 }}>
        <h2 style={{ color:'#d4af37' }}>New Arrivals</h2>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:20 }}>
          {products.map(p => (
            <div key={p._id} style={{ background:'#111', padding:12, borderRadius:8 }}>
              <img src={p.images && p.images[0] ? p.images[0] : 'https://via.placeholder.com/400'} alt={p.title} style={{ width:'100%', height:180, objectFit:'cover', borderRadius:6 }} />
              <h3>{p.title}</h3>
              <p style={{ color:'#ccc' }}>{p.description}</p>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <strong style={{ color:'#d4af37' }}>₹{p.price}</strong>
                <button style={{ background:'#d4af37', border:'none', padding:'8px 12px', borderRadius:6 }}>Add</button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
export default App;
