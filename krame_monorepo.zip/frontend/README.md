# KRAMÉ Frontend (simplified)
Set REACT_APP_API_URL in .env to point to your backend API.
